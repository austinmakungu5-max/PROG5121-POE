/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package quickchat;

/**
 *
 * @author user
 */


import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Messagetest {
public static void main(String[] args) {
}    
 
    @Test
    public void testMessageLengthSuccess() {

        Message msg =
                new Message(
                        0,
                        "+27718693002",
                        "Hi Mike");

        assertEquals(
                "Message ready to send.",
                msg.checkMessageLength());
    }

    @Test
    public void testRecipientSuccess() {

        Message msg =
                new Message(
                        0,
                        "+27718693002",
                        "Hello");

        assertEquals(
                "Cell phone number successfully captured.",
                msg.checkRecipientCell());
    }

    @Test
    public void testMessageID() {

        Message msg =
                new Message(
                        0,
                        "+27718693002",
                        "Hello");

        assertTrue(msg.checkMessageID());
    }
}
