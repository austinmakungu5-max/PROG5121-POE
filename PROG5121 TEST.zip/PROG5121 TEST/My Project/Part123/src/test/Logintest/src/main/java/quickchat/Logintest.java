/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package quickchat;

/**
 *
 * @author user
 */



import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Logintest {
public static void main(String[] args) {
    }        
    
    /**
     *
     */
    @Test
    public void testUsernameCorrectlyFormatted() {

        Login login =
                new Login(
                        "Kyle",
                        "Smith",
                        "kyl_1",
                        "Ch&&sec@ke99!",
                        "+27838968976");

        assertTrue(login.checkUserName());
    }

    @Test
    public void testUsernameIncorrectlyFormatted() {

        Login login =
                new Login(
                        "Kyle",
                        "Smith",
                        "kyle!!!!!!!",
                        "Ch&&sec@ke99!",
                        "+27838968976");

        assertFalse(login.checkUserName());
    }

    @Test
    public void testPasswordComplexity() {

        Login login =
                new Login(
                        "Kyle",
                        "Smith",
                        "kyl_1",
                        "Ch&&sec@ke99!",
                        "+27838968976");

        assertTrue(login.checkPasswordComplexity());
    }

    @Test
    public void testPasswordFailed() {

        Login login =
                new Login(
                        "Kyle",
                        "Smith",
                        "kyl_1",
                        "password",
                        "+27838968976");

        assertFalse(login.checkPasswordComplexity());
    }

    private static class Login {

        public Login() {
        }

        private Login(String kyle, String smith, String kyl_1, String password, String string) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }


        private boolean checkUserName() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private boolean checkPasswordComplexity() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }
    }
}
