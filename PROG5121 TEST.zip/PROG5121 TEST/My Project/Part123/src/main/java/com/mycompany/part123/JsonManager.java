/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.part123;

/**
 *
 * @author user
 */

import com.google.gson.Gson;
import java.io.FileWriter;
import java.io.IOException;

public class JsonManager {

    public static void storeMessage(Message message) {

        Gson gson = new Gson();

        try (FileWriter writer =
                     new FileWriter("messages.json", true)) {

            gson.toJson(message, writer);
            writer.write(System.lineSeparator());

        } catch (IOException e) {

            System.out.println("Error storing message.");
        }
    }
}

