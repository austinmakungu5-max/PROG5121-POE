/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.part123;

/**
 *
 * @author user
 */

import java.util.Random;

public class Message {
public static void main(String[] args) { 
}  
    private static int totalMessages = 0;

    private String messageID;
    private final  int messageNumber;
    private final  String recipient;
    private final  String message;
    private String messageHash;

    public Message(int messageNumber,
                   String recipient,
                   String message) {

        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.message = message;

        generateMessageID();
        createMessageHash();
    }

    private void generateMessageID() {

        Random random = new Random();

        long number =
                1000000000L
                + (long)(random.nextDouble()
                * 8999999999L);

        messageID = String.valueOf(number);
    }

    public boolean checkMessageID() {

        return messageID.length() <= 10;
    }

    public String checkRecipientCell() {

        if (recipient.matches("^\\+27\\d{9}$")) {

            return "Cell phone number successfully captured.";
        }

        return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
    }

    public String checkMessageLength() {

        if (message.length() <= 250) {

            return "Message ready to send.";
        }

        int exceeded = message.length() - 250;

        return "Message exceeds 250 characters by "
                + exceeded
                + ", please reduce the size.";
    }

    public final String createMessageHash() {

        String[] words = message.split(" ");

        String firstWord = words[0];
        String lastWord = words[words.length - 1];

        messageHash =
                messageID.substring(0, 2)
                + ":"
                + messageNumber
                + ":"
                + firstWord.toUpperCase()
                + lastWord.toUpperCase();

        return messageHash;
    }

    public String sentMessage(int choice) {

        switch (choice) {

            case 1 -> {
                totalMessages++;
                return "Message successfully sent.";
        }

            case 2 -> {
                return "Press 0 to delete message.";
        }

            case 3 -> {
                JsonManager.storeMessage(this);
                return "Message successfully stored.";
        }

            default -> {
                return "Invalid option.";
        }
        }
    }

    public String printMessages() {

        return "Message ID: " + messageID
                + "\nMessage Hash: " + messageHash
                + "\nRecipient: " + recipient
                + "\nMessage: " + message;
    }

    public static int returnTotalMessages() {

        return totalMessages;
    }

    public String getMessageID() {
        return messageID;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessage() {
        return message;
    }

    public String getMessageHash() {
        return messageHash;
    }
}