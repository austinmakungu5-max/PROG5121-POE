/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.part123;

/**
 *
 * @author user
 */

import java.util.Random;
import java.util.regex.Pattern;

public class Login {

    private final String firstName;
    private final String lastName;
    private final String username;
    private final String password;
    private final String cellphone;

    public Login(String firstName,
                 String lastName,
                 String username,
                 String password,
                 String cellphone) {

        this.firstName = firstName;
        this.lastName = lastName;
        this.username = username;
        this.password = password;
        this.cellphone = cellphone;
    }

    public boolean checkUserName() {

        return username.contains("_")
                && username.length() <= 5;
    }

    public boolean checkPasswordComplexity() {

        String regex =
                "^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?]).{8,}$";

        return Pattern.matches(regex, password);
    }

    public boolean checkCellPhoneNumber() {

        String regex = "^\\+27\\d{9}$";

        return Pattern.matches(regex, cellphone);
    }

    public String registerUser() {

        if (!checkUserName()) {

            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        }

        if (!checkPasswordComplexity()) {

            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }

        if (!checkCellPhoneNumber()) {

            return "Cell phone number incorrectly formatted or does not contain international code.";
        }

        return "User registered successfully.";
    }

    public boolean loginUser(String enteredUsername,
                             String enteredPassword) {

        return enteredUsername.equals(username)
                && enteredPassword.equals(password);
    }

    public String returnLoginStatus(boolean status) {

        if (status) {

            return "Welcome "
                    + firstName
                    + ", "
                    + lastName
                    + " it is great to see you again.";
        }

        return "Username or password incorrect, please try again.";
    }
}

