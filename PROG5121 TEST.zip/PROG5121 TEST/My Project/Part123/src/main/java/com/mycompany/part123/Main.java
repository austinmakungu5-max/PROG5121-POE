/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.part123;

/**
 *
 * @author user
 */


import com.arangodb.internal.velocystream.MessageStore;
import java.util.Random;
import java.util.Scanner;
import java.util.regex.Pattern;

public class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("=== QUICKCHAT ===");

        System.out.print("First Name: ");
        String firstName = input.nextLine();

        System.out.print("Last Name: ");
        String lastName = input.nextLine();

        System.out.print("Username: ");
        String username = input.nextLine();

        System.out.print("Password: ");
        String password = input.nextLine();

        System.out.print("Cell Number: ");
        String cell = input.nextLine();

        Login login = new Login(firstName, lastName, username, password, cell);
        System.out.println(login.registerUser());

        System.out.println("\nLOGIN");
        System.out.print("Enter Username: ");
        String enteredUser = input.nextLine();

        System.out.print("Enter Password: ");
        String enteredPass = input.nextLine();

        boolean loggedIn = login.loginUser(enteredUser, enteredPass);
        System.out.println(login.returnLoginStatus(loggedIn));

        if (!loggedIn) {
            return;
        }

        System.out.println("\nWelcome to QuickChat.");
        System.out.print("How many messages? ");
        int total = input.nextInt();
        input.nextLine();

        for (int i = 1; i <= total; i++) {
            System.out.println("\nMessage " + i);
            System.out.print("Recipient: ");
            String recipient = input.nextLine();

            System.out.print("Message: ");
            String messageText = input.nextLine();

            Message msg = new Message(i, recipient, messageText);
            System.out.println(msg.checkRecipientCell());
            System.out.println(msg.checkMessageLength());

            System.out.println("""
                    1. Send Message
                    2. Disregard Message
                    3. Store Message
                    """);

            int choice = input.nextInt();
            input.nextLine();

            String result = msg.sentMessage(choice);
            System.out.println(result);
            System.out.println(msg.printMessages());

            switch (choice) {
                case 1 -> MessageStore.sentMessages.add(msg);
                case 2 -> MessageStore.disregardedMessages.add(msg);
                case 3 -> MessageStore.storedMessages.add(msg);
            }
        }

        System.out.println("\nTotal Sent Messages: " + Message.returnTotalMessages());
    }
}







